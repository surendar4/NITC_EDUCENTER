<!DOCTYPE html>
<html >
  <head>
    <meta charset='UTF-8'>
    <title>MESSAGES | NITC EDU-CENNTER </title>
    
    
    <link rel='stylesheet' href='css_c/reset.css'>

    
        <link rel='stylesheet' href='css_c/style.css'>

    <?php
        session_start();
    ?>
  </head>

  <body>
<?php 
                                  $servername = "athena.nitc.ac.in";
                                  $username = "b130417cs";
                                  $password = "b130417cs";
                                  $dbname = "db_b130417cs";

                                  // Create connection
                                  $conn = mysqli_connect($servername, $username, $password, $dbname);

                                  // Check connection
                                  if (!$conn) 
                                  {
                                      die('Connection failed: ' . mysqli_connect_error());
                                  }

   echo "<div class='wrapper'>
    <div class='container'>
        <div class='left'>
            <div class='top'>
                <input type='text' placeholder='Search'/>
                <a href='javascript:;' class='search'></a>
            </div>
            <ul class='people'>";
            $usid=$_SESSION["user"];
            $sql = "SELECT distinct uname,fname,lname,img FROM user where uname IN((Select sendid from message where recid='$usid' order by date asc)) or uname IN((Select recid from message where sendid='$usid' order by date asc));";
            $result = mysqli_query($conn,$sql);
            if($result->num_rows>0)
            {
                $i=0;
                while($row=mysqli_fetch_assoc($result))
                {

                    $fname=$row["fname"];
                    $uname=$row["uname"];
                    $user_list[$i]=$uname;
                    $img=$row["img"];
                    $i++;
                    $sql_fm="SELECT message , date,mid from message where sendid='$usid' and recid='$uname' or sendid='$uname' and recid='$usid' order by mid desc limit 1; ";
                    $result_fm=mysqli_query($conn,$sql_fm);
                    while($row_fm=mysqli_fetch_assoc($result_fm))
                    {
                        $fm=$row_fm["message"];
                        $date_fm=$row_fm["date"];
                    }
               echo  "<li class='person' data-chat='$uname'>
                    <img src='$img' alt='' />
                    <span class='name'>$fname</span>
                    <span class='time'>$date_fm</span>
                    <span class='preview'>$fm</span>
                </li>";
            }
               
           echo "</ul></div>
        
        <div class='right'>
            <div class='top'><span>To: <span class='name'>$fname</span></span></div>
            <div class='chat' data-chat='$user_list[0]'>
                <div class='conversation-start'>
                    <span>Today, 6:48 AM</span>
                </div>
                <div class='bubble you'>
                    Hello,
                </div>
                <div class='bubble you'>
                    it's me.
                </div>
                <div class='bubble you'>
                    I was wondering...
                </div>
            </div>
            <div class='chat' data-chat='$user_list[1]'>
                <div class='conversation-start'>
                    <span>Today, 5:38 PM</span>
                </div>
                <div class='bubble you'>
                    Hello, can you hear me?
                </div>
                <div class='bubble you'>
                    I'm in California dreaming
                </div>
                <div class='bubble me'>
                    ... about who we used to be.
                </div>
                <div class='bubble me'>
                    Are you serious?
                </div>
                <div class='bubble you'>
                    When we were younger and free...
                </div>
                <div class='bubble you'>
                    I've forgotten how it felt before
                </div>
            </div>
            <div class='chat' data-chat='$user_list[2]'>
                <div class='conversation-start'>
                    <span>Today, 3:38 AM</span>
                </div>
                <div class='bubble you'>
                    Hey human!
                </div>
                <div class='bubble you'>
                    Umm... Someone took a shit in the hallway.
                </div>
                <div class='bubble me'>
                    ... what.
                </div>
                <div class='bubble me'>
                    Are you serious?
                </div>
                <div class='bubble you'>
                    I mean...
                </div>
                <div class='bubble you'>
                    It’s not that bad...
                </div>
                <div class='bubble you'>
                    But we’re probably gonna need a new carpet.
                </div>
            </div>
            <div class='chat' data-chat='$user_list[3]'>
                <div class='conversation-start'>
                    <span>Yesterday, 4:20 PM</span>
                </div>
                <div class='bubble me'>
                    Hey human!
                </div>
                <div class='bubble me'>
                    Umm... Someone took a shit in the hallway.
                </div>
                <div class='bubble you'>
                    ... what.
                </div>
                <div class='bubble you'>
                    Are you serious?
                </div>
                <div class='bubble me'>
                    I mean...
                </div>
                <div class='bubble me'>
                    It’s not that bad...
                </div>
            </div>
            <div class='chat' data-chat='$user_list[4]'>
                <div class='conversation-start'>
                    <span>Today, 6:28 AM</span>
                </div>
                <div class='bubble you'>
                    Wasup
                </div>
                <div class='bubble you'>
                    Wasup
                </div>
                <div class='bubble you'>
                    Wasup for the third time like is <br />you bling bitch
                </div>

            </div>
            <div class='chat' data-chat='$user_list[5]'>
                <div class='conversation-start'>
                    <span>Monday, 1:27 PM</span>
                </div>
                <div class='bubble you'>
                    So, how's your new phone?
                </div>
                <div class='bubble you'>
                    You finally have a smartphone :D
                </div>
                <div class='bubble me'>
                    Drake?
                </div>
                <div class='bubble me'>
                    Why aren't you answering?
                </div>
                <div class='bubble you'>
                    howdoyoudoaspace
                </div>
            </div>
            <div class='chat' data-chat='$user_list[6]'>
                <div class='conversation-start'>
                    <span>Today, 6:28 AM</span>
                </div>
                <div class='bubble you'>
                    Wasup
                </div>
                <div class='bubble you'>
                    Wasup
                </div>
                <div class='bubble you'>
                    Wasup for the third time like is <br />you bling bitch
                </div>

            </div>
            <div class='chat' data-chat='$user_list[7]'>
                <div class='conversation-start'>
                    <span>Today, 6:28 AM</span>
                </div>
                <div class='bubble you'>
                    Wasup
                </div>
                <div class='bubble you'>
                    Wasup
                </div>
                <div class='bubble you'>
                    Wasup for the third time like is <br />you bling bitch
                </div>

            </div>
            <div class='chat' data-chat='$user_list[8]'>
                <div class='conversation-start'>
                    <span>Today, 6:28 AM</span>
                </div>
                <div class='bubble you'>
                    Wasup
                </div>
                <div class='bubble you'>
                    Wasup
                </div>
                <div class='bubble you'>
                    Wasup for the third time like is <br />you bling bitch
                </div>

            </div>
            <div class='chat' data-chat='$user_list[9]'>
                <div class='conversation-start'>
                    <span>Today, 6:28 AM</span>
                </div>
                <div class='bubble you'>
                    Wasup
                </div>
                <div class='bubble you'>
                    Wasup
                </div>
                <div class='bubble you'>
                    Wasup for the third time like is <br />you bling bitch
                </div>

            </div>
            <div class='write'>
                <a href='javascript:;' class='write-link attach'></a>
                <input type='text' />
                <a href='javascript:;' class='write-link smiley'></a>
                <a href='javascript:;' class='write-link send'></a>
            </div>
        </div>
    </div>
</div>";
}
echo "<!-- <span class='credits'>design: <a href='https://dribbble.com/Miksa' target='_blank'>milan</a>, code: <a href='http://codepen.io/Momciloo' target='_blank'>momcilo</a></span> -->
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

        <script src='js/index.js'></script>" ?>

    
    
    
  </body>
</html>
