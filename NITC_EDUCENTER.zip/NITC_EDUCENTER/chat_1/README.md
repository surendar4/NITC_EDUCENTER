2015-05-28 : Créationd'un chat en php

             jquery en se basant sur le tuto du site  >http://www.codedodle.com/2014/04/facebook-like-chat-application-in-php.html


Installation : 

				1> install database (show database directory, and lunch index01.php and index02.php to chat)