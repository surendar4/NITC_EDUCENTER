<?php 
    $servername='athena.nitc.ac.in';
    $username='b130417cs';
    $password='b130417cs';
    $db='db_b130417cs';
    $conn=mysqli_connect($servername,$username,$password,$db);
    if (!$conn) {
    die('Connection failed: ' . mysqli_connect_error());
}
?>