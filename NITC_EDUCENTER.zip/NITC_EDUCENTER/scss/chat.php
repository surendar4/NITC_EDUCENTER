<!DOCTYPE html>
<html >
  <head>
    <meta charset='UTF-8'>
    <title>MESSAGES | NITC EDU-CENNTER </title>
    
    
    <link rel='stylesheet' href='css_c/reset.css'>

    
        <link rel='stylesheet' href='css_c/style.css'>

    <?php
        session_start();
    ?>
  </head>

  <body>
<?php 
                                  $servername = "athena.nitc.ac.in";
                                  $username = "b130417cs";
                                  $password = "b130417cs";
                                  $dbname = "db_b130417cs";

                                  // Create connection
                                  $conn = mysqli_connect($servername, $username, $password, $dbname);

                                  // Check connection
                                  if (!$conn) 
                                  {
                                      die('Connection failed: ' . mysqli_connect_error());
                                  }

                                  	if($_SESSION["user"]==NULL)
                                  	{
                                  		header('Location: login.php');
                                  	}

   echo "<div class='wrapper'>
    <div class='container'>
        <div class='left'>
            <div class='top'>
                <input type='text' placeholder='Search'/>
                <a href='javascript:;' class='search'></a>
            </div>
            <ul class='people'>";
            $usid=$_SESSION["user"];
            $sql = "SELECT distinct uname,fname,lname,img FROM user where uname IN((Select sendid from message where recid='$usid' order by date asc)) or uname IN((Select recid from message where sendid='$usid' order by date asc));";
            $result = mysqli_query($conn,$sql);
            if($result->num_rows>0)
            {
                $i=0;
                while($row=mysqli_fetch_assoc($result))
                {

                    $fname=$row["fname"];
                    $uname=$row["uname"];
                    $user_list[$i]=$uname;
                    $img=$row["img"];
                    $i++;
                    $sql_fm="SELECT message , date,mid from message where sendid='$usid' and recid='$uname' or sendid='$uname' and recid='$usid' order by mid desc limit 1; ";
                    $result_fm=mysqli_query($conn,$sql_fm);
                    while($row_fm=mysqli_fetch_assoc($result_fm))
                    {
                        $fm=$row_fm["message"];
                        $date_fm=$row_fm["date"];
                    }
               echo  "<li class='person' data-chat='$uname'>
                    <img src='$img' alt='' />
                    <span class='name'>$fname</span>
                    <span class='time'>$date_fm</span>
                    <span class='preview'>$fm</span>
                </li>";
            }
               
           echo "</ul></div>
        
        <div class='right'>
            <div class='top'><span>To: <span class='name'>$fname</span></span></div>";

           echo "<div class='chat' data-chat='$user_list[0]'>
                <div class='conversation-start'>
                    <span>$date_fm</span>
                </div>";
                $sql_msg1="select sendid,message,date from message where sendid='$user_list[0]' and recid='$usid' or sendid='$usid' and recid='$user_list[0]' ;";
                $result_msg1=mysqli_query($conn,$sql_msg1);
                if($result_msg1->num_rows>0)
                {
                    while($row_msg1=mysqli_fetch_assoc($result_msg1))
                    {
                        $id=$row_msg1["sendid"];
                        $msg1=$row_msg1["message"];
                        $date1=$row_msg1["date"];
                        if($id==$usid)
                        {
                            echo "<div class='bubble me'>
                                            $msg1
                                        </div>";
                        }
                        else
                            echo "<div class='bubble you'>
                                        $msg1
                                    </div>";

                    }
                }
                
           echo " </div>";

           echo "<div class='chat' data-chat='$user_list[2]'>
                <div class='conversation-start'>
                    <span>$date_fm</span>
                </div>";
                $sql_msg2="select sendid,message,date from message where sendid='$user_list[2]' and recid='$usid' or sendid='$usid' and recid='$user_list[2]' ;";
                $result_msg2=mysqli_query($conn,$sql_msg2);
                if($result_msg2->num_rows>0)
                {
                    while($row_msg2=mysqli_fetch_assoc($result_msg2))
                    {
                        $id=$row_msg2["sendid"];
                        $msg2=$row_msg2["message"];
                        $date2=$row_msg2["date"];
                        if($id==$usid)
                        {
                            echo "<div class='bubble me'>
                                            $msg2
                                        </div>";
                        }
                        else
                            echo "<div class='bubble you'>
                                        $msg2
                                    </div>";

                    }
                }
                
           echo " </div>";

            echo "<div class='chat' data-chat='$user_list[1]'>
                <div class='conversation-start'>
                    <span>$date_fm</span>
                </div>";
                $sql_msg_1="select sendid,message,date from message where sendid='$user_list[1]' and recid='$usid' or sendid='$usid' and recid='$user_list[1]' ;";
                $result_msg_1=mysqli_query($conn,$sql_msg_1);
                if($result_msg_1->num_rows>0)
                {
                    while($row_msg_1=mysqli_fetch_assoc($result_msg_1))
                    {
                        $id=$row_msg_1["sendid"];
                        $msg_1=$row_msg_1["message"];
                        $date_1=$row_msg_1["date"];
                        if($id==$usid)
                        {
                            echo "<div class='bubble me'>
                                            $msg_1
                                        </div>";
                        }
                        else
                            echo "<div class='bubble you'>
                                        $msg_1
                                    </div>";

                    }
                }
                
           echo " </div>";
            echo "<div class='chat' data-chat='$user_list[3]'>
                <div class='conversation-start'>
                    <span>$date_fm</span>
                </div>";
                $sql_msg3="select sendid,message,date from message where sendid='$user_list[3]' and recid='$usid' or sendid='$usid' and recid='$user_list[3]' ;";
                $result_msg3=mysqli_query($conn,$sql_msg3);
                if($result_msg3->num_rows>0)
                {
                    while($row_msg3=mysqli_fetch_assoc($result_msg3))
                    {
                        $id=$row_msg3["sendid"];
                        $msg3=$row_msg3["message"];
                        $date3=$row_msg3["date"];
                        if($id==$usid)
                        {
                            echo "<div class='bubble me'>
                                            $msg3
                                        </div>";
                        }
                        else
                            echo "<div class='bubble you'>
                                        $msg3
                                    </div>";

                    }
                }
                
           echo " </div>";

                        echo "<div class='chat' data-chat='$user_list[4]'>
                <div class='conversation-start'>
                    <span>$date_fm</span>
                </div>";
                $sql_msg4="select sendid,message,date from message where sendid='$user_list[4]' and recid='$usid' or sendid='$usid' and recid='$user_list[4]' ;";
                $result_msg4=mysqli_query($conn,$sql_msg4);
                if($result_msg4->num_rows>0)
                {
                    while($row_msg4=mysqli_fetch_assoc($result_msg4))
                    {
                        $id=$row_msg4["sendid"];
                        $msg4=$row_msg4["message"];
                        $date4=$row_msg4["date"];
                        if($id==$usid)
                        {
                            echo "<div class='bubble me'>
                                            $msg4
                                        </div>";
                        }
                        else
                            echo "<div class='bubble you'>
                                        $msg4
                                    </div>";

                    }
                }
                
           echo " </div>";

            echo "<div class='write'>
                <a href='javascript:;' class='write-link attach'></a>
                <input type='text' />
                <a href='javascript:;' class='write-link smiley'></a>
                <a href='javascript:;' class='write-link send'></a>
            </div>
        </div>
    </div>
</div>";
}
echo "<!-- <span class='credits'>design: <a href='https://dribbble.com/Miksa' target='_blank'>milan</a>, code: <a href='http://codepen.io/Momciloo' target='_blank'>momcilo</a></span> -->
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

        <script src='js/index.js'></script>";
         ?>

    
    
    
  </body>
</html>
